// This component is obsolete and has been removed.
// The application now uses standard sign-in and sign-up pages
// instead of a wallet connection modal.
export default () => null;
