// This component has been removed as part of the transition away from mock data structures.
export default () => null;